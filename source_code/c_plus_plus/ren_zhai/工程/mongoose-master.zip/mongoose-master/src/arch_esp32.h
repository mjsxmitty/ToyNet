#pragma once

#if MG_ARCH == MG_ARCH_ESP32

#include <dirent.h>
#include <netdb.h>
#define MG_DIRSEP '/'

#endif

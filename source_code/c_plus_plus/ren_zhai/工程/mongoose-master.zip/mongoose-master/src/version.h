#pragma once
#define MG_VERSION "7.1"

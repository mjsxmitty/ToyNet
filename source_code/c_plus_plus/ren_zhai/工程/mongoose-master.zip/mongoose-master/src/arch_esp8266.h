#pragma once

#if MG_ARCH == MG_ARCH_ESP8266

#include <dirent.h>
#include <esp_system.h>
#include <netdb.h>
#include <stdbool.h>
#include <sys/time.h>
#define MG_DIRSEP '/'

#endif

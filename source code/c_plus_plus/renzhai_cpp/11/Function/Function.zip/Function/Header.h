#pragma once

class FDelegate
{
public:
	virtual void Init(){}
protected:
	enum
	{
		OBJECT,
		FUNCTION,
	}Type;


};

//��򵥵� ֧�ֶ��������
template<class TObjectType, class TReturn, typename ...ParamTypes>
class FObjectDelegate  :public FDelegate
{
public:
	FObjectDelegate(TObjectType* InObject, TReturn(TObjectType::* InFuncation)(ParamTypes ...))
		:Object(InObject)
		, Funcation(InFuncation)
	{
		FDelegate::Type = OBJECT;
	}

	TReturn operator()(ParamTypes &&...Params)
	{
		return (Object->*Funcation)(std::forward<ParamTypes>(Params)...);
	}

private:
	TObjectType* Object;
	TReturn(TObjectType::* Funcation)(ParamTypes ...);
};

template<class TObjectType, class TReturn, typename ...ParamTypes>
class FFunctionDelegate :public FDelegate
{
public:
	FFunctionDelegate(TReturn(TObjectType::* InFuncation)(ParamTypes ...))
		:Funcation(InFuncation)
	{
		FDelegate::Type = FUNCTION;
	}

	TReturn operator()(ParamTypes &&...Params)
	{
		return (*Funcation)(std::forward<ParamTypes>(Params)...);
	}

private:
	TReturn(* Funcation)(ParamTypes ...);
};

class FDelegateBase
{
public:
	FDelegateBase()
		:CurrentDelegate(nullptr)
	{

	}

	void CheckDelegate()
	{
		if (CurrentDelegate)
		{
			delete CurrentDelegate;
			CurrentDelegate = NULL;
		}
	}

	template<class TObjectType, class TReturn, typename ...ParamTypes>
	void Bind(TObjectType* InObject, TReturn(TObjectType::* InFuncation)(ParamTypes ...))
	{
		CheckDelegate();

		CurrentDelegate = new FObjectDelegate<TObjectType, TReturn, ParamTypes...>(InObject, InFuncation);
	}

	template<class TReturn, typename ...ParamTypes>
	void Bind(TReturn(*InFuncation)(ParamTypes ...))
	{
		CheckDelegate();

		CurrentDelegate = new FFunctionDelegate<TReturn, ParamTypes...>(InFuncation);
	}

	template< typename ...ParamTypes >
	void Execute(ParamTypes &&...Params)
	{
		switch (CurrentDelegate->Type)
		{
			case FDelegate::FUNCTION:
			{
				FFunctionDelegate* InDelegate = dynamic_cast<FFunctionDelegate*>(CurrentDelegate);
				
				 (*InDelegate)(std::forward<ParamTypes>(Params)...);
			}
			case FDelegate::OBJECT:
			{
				FObjectDelegate* InDelegate = dynamic_cast<FObjectDelegate*>(CurrentDelegate);
				
				 (*InDelegate)(std::forward<ParamTypes>(Params)...);
			}
		}
	}
	
protected:
	FDelegate* CurrentDelegate;
};
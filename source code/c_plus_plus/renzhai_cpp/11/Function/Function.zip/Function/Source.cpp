#include <iostream>
#include <functional>
#include "Header.h"
using namespace std;

int TT(int a, int b)
{
	cout << "TT" << endl;
	return a + b;
}

auto la = [&](int a, int b)
{
	cout << "TT" << endl;
	return 123;
};

class FHello
{
public:
	int TT(int a, int b)
	{
		cout << "TT" << endl;
		return 123;
	}

	static int TT1(int a, int b)
	{
		cout << "TT" << endl;
		return 123;
	}
};

class FFUnction111
{
public:
	int operator()(int a, int b)
	{
		return a + b;
	}
};

template< class T>
T FuncT(T a, T b)
{
	return a + b;
}

void CallBack(function<int(int, int)> func)
{
	//.....

	int ret = func(1,2);


	//....
}

int(*Func)(int, int);




//�º���������
//TFunction
//TFunctionRef
#include "Header.h"
int main()
{
	//����ָ�� lambda, ��ͨ���� ������ ����bind����
	//������
	//Func = TT;
	//FHello Hello;
	////boost::function

	//bind����
	//function<int(int, int)> Hello_f = bind(&FHello::TT,&Hello, placeholders::_1, placeholders::_2);

	//int ret = Hello_f(1,2);

	//boost::function
	//����
	//function<int(int, int)> Hello_f = FFUnction111();

	//int ret = Hello_f(1, 2);

	//�;�̬
	//function<int(int, int)> Hello_f = FHello::TT1;

	//int ret = Hello_f(1, 2);

	//ģ������
	//function<int(int, int)> Hello_f = FuncT<int>;

	//int ret = Hello_f(1, 2);

	CallBack([&](int a,int b) ->int
	{
		return a + b;
	});

	//�ӳ�
	auto Funcd = bind(TT,1,2);

	//ռλ
	auto Funcd1 = bind(TT,placeholders::_1, placeholders::_2);

	auto Funcd2 = bind(FHello::TT1, 1, 2);

	auto Funcd3 = bind(FuncT<int>, 1, 2);

	int ret = Funcd(4,5);

	FDelegateBase Base;
	Base.Bind(TT);
	Base.Execute(1, 2);
	return 0;
}